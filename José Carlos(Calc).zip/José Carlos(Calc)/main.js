const displayCalc = document.querySelector(".calc :nth-child(1)")
const btns = document.querySelectorAll(".calc .num")

btns.forEach(function (bt) {
    bt.onclick = function() {
        displayCalc.value += bt.textContent
    }
})