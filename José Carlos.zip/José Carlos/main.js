const bts =document.querySelectorAll("div.botoes button")

let turn = 0
const xo = ['X', 'O']

function adicionaClickAosBotoes(bt, index) {
    bt.onclick = function() {
        if (bt.textContent.trim() != '') return
        bt.textContent = xo[turn % 2]
        console.log(index)
        turn++
    }
}

bts.forEach(adicionaClickAosBotoes)